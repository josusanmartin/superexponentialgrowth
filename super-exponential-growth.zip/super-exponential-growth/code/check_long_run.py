"""The human-only path beyond the paper's horizon (Section 5).
Growth stays near 156% a year through 2070 while the share of the power budget in use creeps up.
Once power binds, rationing caps sustained growth at (2.5 * 1.7 * 1.4 / 1.5) ** 0.65 - 1, about 145%."""
import model

p, st, *_ = model.run("trend_only", t_max=46)
print("year  growth   demand / power budget")
for year in (2040, 2045, 2050, 2060, 2070):
    a, b = st(year - 2026), st(year - 2025)
    print(f"{year}  {100 * (b['Y'] / a['Y'] - 1):6.1f}%  {100 * b['GW'] / b['P']:5.1f}%")
print(f"long-run cap once power binds: {100 * ((2.5 * 1.7 * 1.4 / 1.5) ** 0.65 - 1):.1f}%")
