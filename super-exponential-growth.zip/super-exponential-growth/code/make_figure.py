"""Plot the annual full-model paths used in Figure 1."""
import csv
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter, NullLocator

root = Path(__file__).resolve().parents[1]
with (root / "results" / "annual.csv").open() as stream:
    rows = list(csv.DictReader(stream))

plt.rcParams.update({"font.family":"DejaVu Sans", "font.size":9,"pdf.fonttype":42,
                     "axes.spines.top":False,"axes.spines.right":False})
fig, axes = plt.subplots(1,2, figsize=(7.1,3.1), sharey=True)
for ax, title, series in zip(axes, ["A    Software improves 2.5× a year",
                                   "B    Software slows to 1.5× from 2031"],
    [[("baseline","Machine construction, 1 yr","#235787","-"),
      ("baseline_tau2","Machine construction, 2 yr","#008076","-."),
      ("trend_only","Human construction","#625852","--")],
     [("software_slow","Machine construction, 1 yr","#235787","-"),
      ("software_slow_trend","Human construction","#625852","--")]]):
    ax.set_title(title,loc="left", fontsize=9.4,fontweight="bold",pad=9)
    for name,label,color,style in series:
        pts=[(int(r["calendar_year"]),float(r["annual_growth_pct"])) for r in rows
             if r["scenario"]==name and int(r["calendar_year"])<=2045]
        x,y=zip(*pts)
        ax.plot(x,y,label=label,color=color,ls=style,lw=1.9)
    ax.set_yscale("log")
    ax.yaxis.set_minor_locator(NullLocator())
    ax.set_yticks([3,10,30,100,300,1000,3000,10000,30000])
    ax.yaxis.set_major_formatter(FuncFormatter(lambda v,_: f"{v:,.0f}"))
    ax.set_ylim(2.4,62000)
    ax.set_xlim(2026,2045)
    ax.set_xticks([2026,2030,2035,2040,2045])
    ax.tick_params(labelsize=8,length=2)
    ax.grid(axis="y",alpha=.17,lw=.6)
    ax.axhline(30,color="#555",lw=.8,ls=":")
    ax.legend(loc="upper left",fontsize=7.1,frameon=False,handlelength=2)
axes[0].set_ylabel("Annual growth at 2026 prices (%)",fontsize=8.5)
fig.subplots_adjust(left=.10,right=.98,top=.86,bottom=.12,wspace=.16)
fig.savefig(root/"figures"/"construction.pdf")
fig.savefig(root/"figures"/"construction.png",dpi=185)
