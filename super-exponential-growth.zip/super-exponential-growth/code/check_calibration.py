"""Reconstruct the chip-sales comparisons from the cited Epoch AI data vintage.

Run in the replication environment to use the same model parameters.
"""
import math

from model import BASE, SCEN

from epoch_sales import COMPUTE, q4_price_per_h100e, read_sales

rows = read_sales()
value = COMPUTE
assert all(r[value] and float(r[value]) >= 0 for r in rows)
keys = [(r["Name"], r["Start date"], r["End date"]) for r in rows]
assert len(keys) == len(set(keys))
cumulative = sum(float(r[value]) for r in rows if r["End date"] <= "2025-12-31")
print(f"Cumulative estimated sales through 2025 Q4: {cumulative:,.0f} H100e")
assert round(cumulative / 1e6, 1) == BASE["K0"] / 1e6

def quarterly_total(start, end, expected_rows):
    subset = [r for r in rows if r["Start date"] == start and r["End date"] == end]
    assert len(subset) == expected_rows
    assert all(r["Incomplete"].strip().lower() in ("", "false") for r in subset)
    return sum(float(r[value]) for r in subset)

mix_price = q4_price_per_h100e(rows)
assert round(mix_price) == 13588
print(f"Positive-cost 2025 Q4 mix: {mix_price:,.2f} USD per H100e")
q4 = quarterly_total("2025-10-01", "2025-12-31", 14)
q1 = quarterly_total("2026-01-01", "2026-03-31", 11)
q2 = quarterly_total("2026-04-01", "2026-06-30", 15)
print(f"2025 Q4 sales: {q4:,.2f} H100e; four times that pace: {4*q4:,.2f}/year")
print(f"2026 Q1 and Q2 sales: {q1:,.0f} and {q2:,.0f} H100e")
# Before the first machine deliveries, F(t) <= F0 exp(gF t). Even if all
# this capacity is used, integrating it gives an upper bound on chip output.
g = SCEN["baseline"]["gF"]
h1_ceiling = BASE["F0"] * math.expm1(g * 0.5) / g
print(f"2026 H1 sales: {q1+q2:,.0f}; reference production ceiling: {h1_ceiling:,.0f}")
print(f"Ceiling relative to estimated sales: {100*(h1_ceiling/(q1+q2)-1):.2f}%")
assert round(4*q4/1e6, 2) == 17.65
assert round((q1+q2)/1e6, 2) == 11.31
assert round(h1_ceiling/1e6, 2) == 10.31
