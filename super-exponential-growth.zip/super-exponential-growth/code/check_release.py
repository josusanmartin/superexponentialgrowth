"""Check the manuscript's numerical tables and bibliography against the release files."""
import csv
import math
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
paper = (ROOT / "paper.tex").read_text()
body, bibliography = paper.split(r"\begin{thebibliography}", 1)

def read_csv(path):
    with (ROOT / path).open(newline="") as stream:
        return list(csv.DictReader(stream))

def indexed(path, key):
    records = read_csv(path)
    result = {row[key]: row for row in records}
    assert len(result) == len(records), (path, "duplicate row key")
    return result

def table_rows(label):
    table = body.split(r"\label{tab:" + label + "}", 1)[1].split(r"\end{tabular}", 1)[0]
    lines = [line for line in table.splitlines() if "&" in line and r"\\" in line]
    return [[cell.strip() for cell in line.split(r"\\", 1)[0].split("&")] for line in lines]

def equal_printed(cell, value, digits):
    if cell == "$<0.01$":
        assert 0 <= value < 0.01
    else:
        assert float(cell.replace(",", "")) == round(value, digits), (cell, value, digits)

s = indexed("results/scenarios.csv", "scenario")
old = indexed("reference/published_summary.csv", "scenario")
assert len(s) == 48
years = (2035, 2040, 2045)

for label, names, offset in (
    ("main", ("trend_only", "baseline", "baseline_tau2", "software_slow_trend", "software_slow"), 3),
    ("energy", ("archived_energy", "credit_only", "allocation_only", "human_energy"), 2),
):
    for row, name in zip(table_rows(label)[1:], names, strict=True):
        if label == "main":
            equal_printed(row[2], float(s[name]["first_30"]), 2)
        for cell, year in zip(row[offset:], years, strict=True):
            equal_printed(cell, float(s[name][f"growth_{year}_pct"]), 1)

cutoffs, dates = table_rows("cutoff")
for level, cell in zip(cutoffs[1:], dates[1:], strict=True):
    event = s[f"cutoff_{level}"]
    assert event["event"] == "rate"
    equal_printed(cell, float(event["last_year"]), 3)

annual = read_csv("results/annual.csv")
by_year = {(r["scenario"],int(r["calendar_year"])):r for r in annual}
assert len(by_year) == len(annual) and {k[0] for k in by_year} == set(s)
ces = indexed("results/ces.csv", "sigma")
for sigma, g35, g40, share in table_rows("ces")[1:]:
    if sigma in ces:
        r = ces[sigma]
        equal_printed(g35, float(r["g2035"]), 1)
        equal_printed(g40, float(r["g2040"]), 1)
        equal_printed(share, float(r["share2040"]), 2 if sigma == "1" else 1)
    else:
        assert sigma == "Fixed 2026 prices"
        equal_printed(g35, float(s["baseline"]["growth_2035_pct"]), 1)
        equal_printed(g40, float(s["baseline"]["growth_2040_pct"]), 1)
        equal_printed(share, 100*float(by_year["baseline",2040]["mshare"]), 2)

# Independently recalculate each annual growth rate from successive stock observations.
for (name, year), r in by_year.items():
    previous = float(by_year[name, year-1]["Y"]) if year > 2026 else 125e12
    growth = 100 * (float(r["Y"]) / previous - 1)
    assert math.isclose(growth,float(r["annual_growth_pct"]),abs_tol=1e-7,rel_tol=1e-10)
    assert int(r["year"]) == year+1
    assert math.isclose(sum(float(r[k]) for k in ("YH","YA","YR")),float(r["Y"]),rel_tol=1e-12)
for year in years:
    assert math.isclose(float(s["archived_energy"][f"growth_{year}_pct"]),
                        100*float(old["human_energy"][f"g{year}"]), abs_tol=.01)
for name in ("baseline", "human_energy", "annual_robots_baseline"):
    g40 = f"growth_2040_pct"
    assert round(float(s[name][g40]),1) == round(float(s["refined_"+name][g40]),1)
assert round(float(s["refined_baseline_tau0"]["last_year"]),3) == round(float(s["baseline_tau0"]["last_year"]),3)
for name, expected in (("annual_robots_baseline",794.0), ("mix_price_baseline",792.1),
                        ("mix_price_annual_robots_baseline",791.3), ("mix_price_annual_robots_trend_only",153.9)):
    equal_printed(str(expected), float(s[name]["growth_2040_pct"]), 1)
for name, expected in (("four_stock",795),("one_stock",966)):
    series = {float(r["year"]):r for r in read_csv(f"results/{name}_baseline.csv")}
    assert round(100*float(series[2041]["growth_past_12_months"])) == expected

# All inline author-year citations resolve to a displayed item and the matching BibTeX key.
used = set()
for group in re.findall(r"\\cite[pt](?:\[[^\]]*\])?\{([^}]+)\}", body):
    used.update(group.split(","))
items = re.findall(r"\\bibitem\[[^\]]+\]\{([^}]+)\}", bibliography)
exported = re.findall(r"^@[a-z]+\{([^,]+),", (ROOT/"reference/references.bib").read_text(), re.M)
assert len(used) == len(items) == len(exported) and used == set(items) == set(exported)
print(f"Verified {len(s)} paths, {len(annual)} annual observations, four numerical results tables, "
      f"both baseline series, robustness checks and {len(items)} matched references.")
