"""Read the 22 November 2026 snapshot of Epoch AI's chip-family sales estimates."""
import csv
import hashlib
from pathlib import Path

SNAPSHOT = Path(__file__).resolve().parents[1] / "reference" / "epoch-chip-sales-2026-11-22.csv"
SHA256 = "d1ef7989767ec515e3afc439ef6baffd1c733ce6de2004cf04ba30f984b05c03"
COMPUTE = "Compute estimate in H100e (median)"
COST = "Cost Estimate (USD)"

def read_sales():
    if hashlib.sha256(SNAPSHOT.read_bytes()).hexdigest() != SHA256:
        raise ValueError("Chip sales file differs from the cited November 2026 snapshot")
    with SNAPSHOT.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))

def q4_price_per_h100e(rows):
    priced = [r for r in rows if r["Start date"] == "2025-10-01" and
              r["End date"] == "2025-12-31" and float(r[COST]) > 0]
    assert len(priced) == 13
    assert all(r["Incomplete"].strip().lower() in ("", "false") for r in priced)
    return sum(float(r[COST]) for r in priced) / sum(float(r[COMPUTE]) for r in priced)
