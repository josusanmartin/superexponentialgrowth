#!/usr/bin/env bash
# Reproduce every number, table and figure of the paper. About a minute on a laptop.
set -euo pipefail
cd "$(dirname "$0")"
echo "1/5 the full model: 48 paths"
python3 code/reproduce.py > results/run.log
echo "2/5 the one-formula model"
node code/formula_baseline.js
echo "3/5 calibration against the chip-sales snapshot"
python3 code/check_calibration.py
echo "4/5 the paper's tables against the results"
python3 code/check_release.py
echo "5/5 figure and paper"
python3 code/make_figure.py
if command -v pdflatex >/dev/null; then pdflatex -interaction=nonstopmode paper.tex >/dev/null && pdflatex -interaction=nonstopmode paper.tex >/dev/null && echo "paper.pdf rebuilt"; else echo "pdflatex not found: paper.pdf left as shipped"; fi
