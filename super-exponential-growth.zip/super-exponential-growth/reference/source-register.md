# Publication source audit

**Super-Exponential Growth in the Agentic Era**, Josu San Martin. Evidence checked for the 22 November 2026 working paper.

## What the evidence supports

The manuscript compares construction technologies at a specified software trend. Its principal output is a fixed-price service-flow index. The construction and electricity data establish why commissioning takes time. The quoted growth rates, the automation path and cross-sector learning remain conditional model results and assumptions.

## Material corrections before circulation

- **Compute.** Epoch estimates delivered capacity at end-2025. Treating it as operating stock on 1 January 2026 is a proxy. Its 31.6 million H100-equivalent figure for September was an extrapolation. We replaced the secondary coverage story with the researchers’ account. The November sales snapshot gives 17.65 million H100-equivalents per year at the 2025 Q4 sales pace. Its estimated sales in the first half of 2026 exceed the model’s initial production ceiling by about one million equivalents. Sales, production and commissioning have different timing.
- **Chip price.** The archived reference charges $37,000 per H100-equivalent. Epoch’s $37,000 B200 price is per physical chip. Dividing $59.841 billion of estimated chip cost by 4.404 million equivalents in the positive-cost Q4 rows gives $13,587.57 per equivalent. A separate scenario tests that price and keeps capex and other unit costs fixed. See the snapshot attribution and the calculation script in the package.
- **Robot volumes.** The IFR stock and 2025 installations are historical estimates. Its 2026 and 2029 installations and the Bank of America humanoid shipments are forecasts. The original interpolation gives 849,107 gross human-built units before rationing in 2026. Spreading the forecast volumes over the year gives 745,000. Neither series measures autonomous construction hours.
- **Output scale.** The October IMF database places calendar-2026 world GDP at $128.004 trillion in current dollars. The paper uses $125 trillion as an opening normalization. The two firms’ roughly $9 billion and more than $20 billion revenue run rates give context for a $50 billion agent-services assumption. Neither firm reports the worldwide value of autonomous services.
- **Energy.** The original model starts human power additions at 30 GW/year. Continuous growth makes the first two calendar-year additions 35.7 and 49.9 GW. Its end-2030 power budget of 414 GW includes capacity available to robots and allows idle capacity. The IEA’s April all-data-centre Base Case is 226 GW installed, including 174 GW of IT. These different boundaries matter when interpreting early slack in the model.
- **National accounts.** Gross value added, work in progress, completed capital and operating capacity have distinct timing. Growth rates in the simulation compare endpoint service flows. A national-accounts annual growth rate also depends on flows throughout the year, intermediate use and prices.

## Replication and remaining uncertainty

The release contains 48 paths, including 5 calendar-volume comparisons, 4 refined numerical integrations and 4 chip-price comparisons, in addition to the previous 35 paths. At the alternative chip price and annual robot volumes, reference-price output grows 791.3% in 2040 with one-year machine construction and 153.9% with human construction. The archived inputs give 794.8% and 153.8%. At the refined settings the headline rates retain their displayed precision. The numerical cutoff remains a finite event.

The audit checks the reported source units, editions, claims and arithmetic. It does not reconstruct a commercial fab database or establish a causal estimate of a one-year future machine build, sustained software progress, the autonomous-service elasticity, or learning transferred across sectors. A comparable series of repeat builds with hours on the critical path and order-to-operation dates would address the central empirical gap.

## Sources and claim locations

- **Acemoglu (2025)**. Final journal version, summary and ten-year TFP calculation. 0.66% is the cumulative upper estimate, below 0.53% with the hard-task adjustment. Replaces a link to the working paper. [The simple macroeconomics of AI](https://doi.org/10.1093/epolic/eiae042)

- **Aghion et al. (2019)**. Published chapter 9, opening discussion of automation and scarce essential tasks. The original NBER working paper dates to 2017. [Artificial intelligence and economic growth](https://doi.org/10.7208/9780226613475-011)

- **Anthropic (2026)**. Retrospective company statement of approximately $9B run-rate revenue at end-2025. A firm-wide annualized revenue measure. Used only to contextualize the assumed agent-services scale. [Anthropic expands partnership with Google and Broadcom for multiple gigawatts of next-generation compute](https://www.anthropic.com/news/google-broadcom-partnership-compute)

- **Bank of America Institute (2026)**. Exhibit 2, p. 2, BofA Global Research forecast of annual worldwide shipments. 90k, 290k, 500k, 800k and 1.2M for 2026–30. Shipments are not commissioned stock. Input after 2030 is the model’s own extrapolation. [Physical AI, part 2: Humanoid robots](https://institute.bankofamerica.com/content/dam/transformation/physical-ai-part-2.pdf)

- **Bates Ramirez et al. (2026)**. Coverage-method paragraph. 20.3M H100e delivered to major customers by end-2025. 31.6M for September 2026 is explicitly extrapolated. Epoch assumes a three-month deployment lag for coverage. This original account supersedes AlphaSignal. [We're scaling our AI data centers research](https://epoch.ai/latest/scaling-ai-data-centers-research)

- **Becker et al. (2025)**. Version 2, abstract and Fig. 1. Sixteen experienced contributors, 246 tasks randomized to AI permission, 19% longer completion time. Author names follow the title page. [Measuring the impact of early-2025 AI on experienced open-source developer productivity](https://arxiv.org/abs/2507.09089v2)

- **Becker et al. (2026)**. Authors’ follow-up. Selection into participation and tasks and difficulties measuring concurrent agent use make the later estimates unreliable as an estimate of general speedup. [We are changing our developer productivity experiment design](https://metr.org/blog/2026-02-24-uplift-update/)

- **Brosque and Fischer (2022)**. Section 17, Kewazo and TyBot cases. Ten robot types across twelve projects. One 20-level scaffolding case saved 359.5 person-hours using 40% of the crew while unit transport took 78% longer. Subsequent tests differed. [Safety, quality, schedule, and cost impacts of ten construction robots](https://doi.org/10.1007/s41693-022-00072-5)

- **Brynjolfsson et al. (2025)**. Final QJE article, abstract and productivity estimates. Staggered rollout to 5,172 workers and 15% more issues resolved per hour. The earlier working paper has different counts and estimates. [Generative AI at work](https://doi.org/10.1093/qje/qjae044)

- **Davidson and Hadshar (2025)**. Section “Three stages of industrial explosion.” A conceptual scenario from AI-directed human labor to automated factories. The authors describe it as a research note. [The industrial explosion](https://www.forethought.org/research/the-industrial-explosion)

- **Davidson (2021)**. Report assessing whether advanced AI could drive explosive growth; source of the 30% a year threshold used for takeoff. Cited for lineage only. [Could advanced AI drive explosive economic growth?](https://coefficientgiving.org/research/could-advanced-ai-drive-explosive-economic-growth/)

- **Del Boca et al. (2008)**. Final journal abstract and estimation discussion. Annual investment expenditures imply 2–3-year effects for structures and no evidence of effects beyond a year for equipment. Structural estimates, not measured construction-site durations. [Investment and time to plan and build: A comparison of structures vs. equipment in a panel of Italian firms](https://doi.org/10.1162/JEEA.2008.6.4.864)

- **Eash-Gates et al. (2020)**. Published article and MIT accepted manuscript, aggregate design-class analysis. Later U.S. plants cost more on average than first-of-a-kind plants. Total plant costs can rise even with learning on individual tasks. [Sources of cost overrun in nuclear power plant construction call for a new approach to engineering design](https://doi.org/10.1016/j.joule.2020.10.001)

- **Eliahou Ontiveros et al. (2026)**. Public lead and headline forecast about 50 GW of global datacentre additions in 2027. This is an industry forecast, partly by the same analyst as the podcast, not an independent realized power statistic. [Datacenters 2027: The year of acceleration, +50GW in a single year](https://newsletter.semianalysis.com/p/datacenters-2027-the-year-of-acceleration)

- **Epoch AI (2026)**. Chip-family sales CSV, “Compute estimate in H100e (median).” Full vintage preserved byte-for-byte with source attribution. No addition of confidence limits. Sales are estimated from multiple financial and technical inputs. [Data on AI chip sales](https://epoch.ai/data/ai-chip-sales)

- **Erdil et al. (2025)**. Sections 2 and 5. Endogenous research and investment plus capital adjustment costs. ArXiv indexes nine individual authors and the PDF credits Epoch AI on its title page. [GATE: An integrated assessment model for AI automation](https://arxiv.org/abs/2503.04941v2)

- **Erdil and Besiroglu (2023)**. Review of arguments for and against explosive growth from AI automation. Cited for lineage only. [Explosive growth from AI automation](https://arxiv.org/abs/2309.11690)

- **Friar (2026)**. CFO’s account of more than $20B ARR in 2025. Annualized company-wide value. Replaces later reported revenue attributed to the opening period. [A business that scales with the value of intelligence](https://openai.com/index/a-business-that-scales-with-the-value-of-intelligence/)

- **Graetz and Michaels (2018)**. Published estimate, abstract. Increased robot use contributed approximately 0.36 percentage points to annual labor productivity growth in 17 countries, 1993–2007. It gives no estimate of robot construction labor. [Robots at work](https://doi.org/10.1162/rest_a_00754)

- **Gundlach et al. (2026)**. Section 2.4 and Table 2, v2. Open-weight price trends adjusted for hardware price improvements leave a residual of around 3× annually in a sample concentrated in April 2024–November 2025. Distinct from raw token throughput. [The price of progress: Price performance and the future of AI](https://arxiv.org/abs/2511.23455v2)

- **Hobbhahn et al. (2023)**. Summary table and Figs. 6 and 8: ML GPU FP32 price-performance doubles in 2.1 years, FP32 performance per watt in 3.0 years. These are new hardware measurements. The applied 1.37/1.4 multiples are scenario inputs. [Trends in machine learning hardware](https://epoch.ai/publications/trends-in-machine-learning-hardware)

- **IEA (2026a)**. Figure 2.2 compares selected leading processors. Table A.1 gives 226 GW of all-facility capacity, 174 GW IT capacity, and 945 TWh electricity consumption in the 2030 Base Case. Each is a projection with a distinct denominator. [Key questions on energy and AI](https://www.iea.org/reports/key-questions-on-energy-and-ai)

- **IEA (2026b)**. Chapter 1, p. 83, data-centre capacity in the Stated Policies Scenario. Approximately 120 GW of additional capacity by 2030 from an approximately 120 GW contemporary base. This is not annual electricity use. [World Energy Outlook 2026](https://www.iea.org/reports/world-energy-outlook-2026)

- **IFR (2026)**. Executive summary, printed p. 15. 2025 stock 5,079,078 and 603,307 installations are historical estimates. 655,000 installations for 2026 and 806,000 for 2029 are forecasts. [World Robotics 2026: Industrial robots](https://ifr.org/img/worldrobotics/Executive_Summary_WR_2026_-_Industrial_Robots.pdf)

- **IMF (2026a)**. DataMapper world aggregate WEOWORLD, series NGDPD. 2026 = 128,003.776 billion current U.S. dollars. The model’s $125T is an opening normalization for an annualized index. [World Economic Outlook database, October 2026](https://www.imf.org/external/datamapper/profile/WEOWORLD/WEO)

- **IMF (2026b)**. Chapter 1, Table 1.1. Annual real world growth in 2026 and 2027 is projected at 3.1% and 3.4%. The model inserts 0.031 and 0.034 as log rates and extrapolates thereafter. [World Economic Outlook: Resilience under strain, urgent choices](https://www.imf.org/en/Publications/WEO/Issues/2026/10/13/world-economic-outlook-october-2026)

- **ISWGNA (2025)**. 2025 international standard, pre-edit text at the official UNSD site. Chapter 7 on recording output as it accrues and Chapter 11 on work in progress, ownership and fixed capital formation. Operational commissioning is a different event. [System of National Accounts 2025](https://unstats.un.org/unsd/econstats/national-accounts/sna2025)

- **Irwin and Klenow (1994)**. Quarterly DRAM data over 1974–1992, seven product generations. Average learning rate 20%, own marginal experience about three times the other-firm contribution, weak intergenerational spillovers. Chip production is distinct from fab construction. [Learning-by-doing spillovers in the semiconductor industry](https://doi.org/10.1086/261968)

- **Jones and Tonetti (2026)**. Figs. 7–8 and accompanying discussion, pp. 46–48. Private-business asymptotic path grows 2.1% in 2020 and 3.2% in 2050. Computer-sector calibration reaches about 16% in 2040. These are simulated GDP per person growth rates. [Past automation and future AI: How weak links tame the growth explosion](https://web.stanford.edu/~chadj/JonesTonetti_Automation.pdf)

- **Kremer (1993)**. World population growth rates rose with the population level over the long run. Cited for lineage only. [Population growth and technological change: One million B.C. to 1990](https://doi.org/10.2307/2118405)

- **Kydland and Prescott (1982)**. Section 3: multi-period investment precedes productive capital. Cited for the antecedent, not as a measurement of physical AI construction times. [Time to build and aggregate fluctuations](https://doi.org/10.2307/1913386)

- **Li (2026)**. Analysis and data, 2025 Q2–2026 Q2. Applies fixed workload scores to cumulative estimated chip sales. The two growth factors compare measures of hardware capacity, not software quality or realized output. [Agentic inference capacity grew 4.6× in a year, versus 2.6× for compute capacity](https://epoch.ai/data-insights/agentic-inference-capacity-growth)

- **Nordhaus (2021)**. Supply- and demand-side tests for an approaching economic singularity; most are not met. Cited for lineage only. [Are we approaching an economic singularity?](https://doi.org/10.1257/mac.20170105)

- **Ord (2026)**. Version 2, generation-time argument and discussion of nonsingular super-exponential growth. The present paper states its own sufficient condition for the undelayed robot system. [The dynamics of intelligence explosions](https://arxiv.org/abs/2608.14426v2)

- **Patel (2026)**. Opening transcript before 00:07:01. Dylan Patel considers 30/50/70 GW additions in 2026/27/28 and discusses just over $1T of capex. Conditional analyst scenario, not audited construction spending. [Anthropic and OpenAI will have most of the world's compute by 2028](https://www.dwarkesh.com/p/dylan-patel-3)

- **Pichai (2026)**. Opening keynote retrospectively compares roughly 480T to over 3.2 quadrillion tokens/month across Google surfaces. A provider-specific usage series, not an efficiency estimate. [I/O 2026: Welcome to the agentic Gemini era](https://blog.google/innovation-and-ai/sundar-pichai-io-2026/)

- **Rand et al. (2025)**. High-level findings, completion and duration sections. Counts 13% of requested capacity operating, 77% withdrawn, 10% active for the 2000–2019 request cohort through end-2024. Above-four-year median covers completed 2018–24 projects with dates. No behind-the-meter projects. [Queued Up: 2025 edition. Characteristics of power plants seeking transmission interconnection as of the end of 2024](https://eta-publications.lbl.gov/publications/queued-2025-edition-characteristics)

- **Roodman (2020)**. Stochastic model fitted to gross world product since 10,000 BCE; the fitted path diverges this century. Cited for lineage only. [Modeling the human trajectory](https://www.openphilanthropy.org/blog/modeling-human-trajectory)

- **Trammell and Korinek (2026)**. Final journal edition. Distinguishes automation of production from automation of research. Replaces the 2023 NBER citation to the earlier version. [Economic growth under transformative AI](https://doi.org/10.1146/annurev-economics-051624-061002)

- **VerWey (2021)**. Printed pp. 5–6, Fig. 1 and source note. Mean 682 days for 635 completed greenfield fabs with construction and first-production dates, 1990–2020. Omits work before construction start. [No permits, no fabs: The importance of regulatory reform for semiconductor manufacturing](https://cset.georgetown.edu/wp-content/uploads/CSET-No-Permits-No-Fabs.pdf)

- **Virtanen et al. (2020)**. Software citation. The supplementary environment pins SciPy 1.16.3 and NumPy 2.3.4. Solver settings and refined comparisons are in the numerical appendix. [SciPy 1.0: Fundamental algorithms for scientific computing in Python](https://doi.org/10.1038/s41592-019-0686-2)

- **Way et al. (2022)**. Backtested cost forecasting and technology-specific deployment curves for energy technologies. No estimate of a common four-sector learning parameter. [Empirically grounded technology forecasts and the energy transition](https://doi.org/10.1016/j.joule.2022.08.009)

- **Wright (1936)**. Original aircraft-production study, pp. 122–128. Used for the experience-curve functional form; no claim of a modern factory-size or automation estimate. [Factors affecting the cost of airplanes](https://doi.org/10.2514/8.155)
