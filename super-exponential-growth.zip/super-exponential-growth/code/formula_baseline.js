// Baseline path of the one-formula model, quarterly, in trillions of 2026 dollars -> results/one_stock_baseline.csv
const path = require('path'); const m = require('./formula.js'); const r = m.simulate({}, 24);
let csv = 'year,people_output_Y_H,machine_output_Y_M,total_output_Y,machine_capital_K,growth_past_12_months\n';
for (let t = 0; t <= 19 + 1e-9; t += 0.25) csv += [(2026 + t).toFixed(2), Math.exp(m.at(r.S, 'lnH', t)).toFixed(1), Math.exp(m.at(r.S, 'lnM', t)).toPrecision(4),
  Math.exp(m.at(r.S, 'lnY', t)).toPrecision(5), Math.exp(m.at(r.S, 'lnK', t)).toPrecision(4), t >= 1 ? m.growthAt(r.S, t).toFixed(4) : ''].join(',') + '\n';
require('fs').writeFileSync(path.join(__dirname, '..', 'results', 'one_stock_baseline.csv'), csv);
