"""Rebuild the results quoted in the revised manuscript from its four-stock model."""
import csv
import json
import math
import sys
from pathlib import Path
import numpy
import scipy
from scipy.integrate import quad
from model import BASE, robots_human, run
from epoch_sales import q4_price_per_h100e, read_sales

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results"
OUT.mkdir(exist_ok=True)

def save(name, rows):
    with (OUT / name).open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=rows[0])
        writer.writeheader()
        writer.writerows(rows)


scenarios = ["baseline", "trend_only", "baseline_tau0", "baseline_tau2", "software_slow",
             "software_slow_trend", "human_energy", "replication_only", "repl_plus_intel",
             "repl_plus_learn", "absorption_bound", "displacement", "chips_redirect", "slow", "fast"]
jobs = [(s, s, {}) for s in scenarios]
jobs += [(f"cutoff_{c}", "baseline_tau0", {"rate_stop":c, "stock_stop":120}) for c in (25, 50, 100, 200, 400, 800)]
jobs += [(f"dispatch_{w}", "human_energy", {"dispatch_window":w}) for w in (0.005, 0.02)]
jobs += [("archived_energy", "human_energy", {"legacy_power_rule":True,"legacy_experience":True}),
         ("credit_only", "human_energy", {"legacy_power_rule":True}),
         ("allocation_only", "human_energy", {"legacy_experience":True})]
for key, values in {"LR":[0.05,0.25], "rho":[0.5,0.8], "Ta":[5.,12.], "tau":[0.25,0.5,3.]}.items():
    jobs += [(f"{key}_{v}", "baseline", {key:v}) for v in values]
for name in ("baseline", "trend_only", "baseline_tau2", "software_slow", "software_slow_trend"):
    jobs.append((f"annual_robots_{name}", name, {"annual_robot_volumes": True}))
for name in ("baseline", "human_energy", "baseline_tau0", "annual_robots_baseline"):
    options = {"max_step": 0.005, "rtol": 1e-9}
    scenario = name
    if name == "annual_robots_baseline":
        scenario = "baseline"
        options["annual_robot_volumes"] = True
    jobs.append((f"refined_{name}", scenario, options))
mix_price = q4_price_per_h100e(read_sales())
for name in ("baseline", "trend_only"):
    jobs.append((f"mix_price_{name}", name, {"pC0": mix_price}))
    jobs.append((f"mix_price_annual_robots_{name}", name, {"pC0": mix_price, "annual_robot_volumes": True}))
summary, annual = [], []
print("VERSIONS", sys.version.split()[0], numpy.__version__, scipy.__version__, flush=True)
annual_params = {**BASE, "annual_robot_volumes":True}
print(f"2025 Q4 chip mix price: {mix_price:.4f} USD per H100e", flush=True)
for year in range(5):
    target = BASE["ind0"] * math.exp(BASE["ind_g"]*year) + BASE["hum"][year]
    archived_flow = quad(robots_human, year, year+1, args=(BASE,))[0]
    calendar_flow = quad(robots_human, year, year+1, args=(annual_params,))[0]
    assert math.isclose(calendar_flow, target, rel_tol=1e-11)
    print(f"ROBOT FLOW {2026+year}: January-rate path {archived_flow:.2f}; calendar-volume path {calendar_flow:.2f} units", flush=True)
for i, (name, scenario, over) in enumerate(jobs, 1):
    p, state, growth, event, stop, first, crossover = run(scenario, over)
    row = dict(scenario=name, first_30=first, crossover=crossover, last_year=2026+stop, event=event)
    for year in (2030, 2035, 2040, 2045):
        t = year-2025
        row[f"growth_{year}_pct"] = 100*growth(t) if t<=stop else None
    summary.append(row)
    peak_ratio = max(state(j/100)["GW"]/state(j/100)["P"] for j in range(int(stop*100)+1))
    if not over.get("legacy_power_rule"):
        assert peak_ratio < 1.0001, (name, peak_ratio)
    print("PATH", json.dumps(row), "max demand/capacity", peak_ratio, flush=True)
    for yr in range(2026,2049):
        t = yr-2025
        if t>stop: break
        annual.append(dict(scenario=name,calendar_year=yr,annual_growth_pct=growth(t)*100,**state(t)))
    if name == "baseline":
        quarterly = []
        for j in range(81):
            t = j/4
            s = state(t)
            quarterly.append(dict(year=2026+t,people_output_trillion=s["YH"]/1e12,
                machine_output_trillion=(s["YA"]+s["YR"])/1e12,total_output_trillion=s["Y"]/1e12,
                growth_past_12_months=growth(t) if t>=1 else None))
        save("four_stock_baseline.csv",quarterly)
        initial = state(0)
        m0 = initial["YA"]+initial["YR"]
        omega = m0/initial["Y"]
        ces = []
        for sigma in (.5,1,1.5,2,3):
            def index(t):
                s = state(t)
                m = (s["YA"]+s["YR"])/m0
                h = s["YH"]/initial["YH"]
                if sigma == 1:
                    return h**(1-omega)*m**omega, omega
                r = 1-1/sigma
                total = (1-omega)*h**r+omega*m**r
                return total**(1/r), omega*m**r/total
            ces.append(dict(sigma=sigma,g2035=100*(index(10)[0]/index(9)[0]-1),
                            g2040=100*(index(15)[0]/index(14)[0]-1),share2040=100*index(15)[1]))
        print("CES",ces,flush=True)
        save("ces.csv",ces)
save("scenarios.csv",summary)
save("annual.csv",annual)
