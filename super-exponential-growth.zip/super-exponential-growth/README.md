# Super-Exponential Growth in the Agentic Era

Josu San Martin. Working paper, November 2026.
Interactive version: https://superexponentialgrowth.fun

`paper.pdf` is the paper and `paper.tex` its source. Everything else reproduces its numbers.

## Reproduce

    pip install -r requirements.txt
    ./run_all.sh

This runs the full model (48 paths, about half a minute), exports the one-formula baseline, checks the
calibration against the chip-sales snapshot, checks every number in the paper's tables against the fresh
results, redraws Figure 1 and rebuilds the PDF.

You need Python 3.10 or later with numpy, scipy and matplotlib, and Node 18 or later for the one-formula
model. pdflatex is optional; without it the shipped `paper.pdf` is left in place. The results in this folder
were produced with Python 3.13, NumPy 2.3 and SciPy 1.16, and agree with a rerun on NumPy 2.5 and SciPy 1.18
to rounding error. The model is deterministic.

## Where each result comes from

| In the paper | Script | Output |
| --- | --- | --- |
| Table 1 (builders and software trends), Figure 1 | `code/reproduce.py`, `code/make_figure.py` | `results/scenarios.csv`, `results/annual.csv`, `figures/construction.pdf` |
| Table 2 (human-built power) | `code/reproduce.py` | `results/scenarios.csv` |
| Table 3 (instant construction, cutoff dates) | `code/reproduce.py` | `results/scenarios.csv`, rows `cutoff_*` |
| Table 4 (price index) | `code/reproduce.py` | `results/ces.csv` |
| The one formula (Section 4) | `code/formula.js`, `code/formula_baseline.js` | `results/one_stock_baseline.csv` |
| Chip-sales and chip-price checks (Sections 2 and 5) | `code/epoch_sales.py`, `code/check_calibration.py` | printed |
| Human-only growth beyond 2045 and its long-run cap (Section 5) | `code/check_long_run.py` | printed |
| Quarterly baseline of the full model | `code/reproduce.py` | `results/four_stock_baseline.csv` |

`code/model.py` is the model: `BASE` holds the calibration and `SCEN` the scenarios. `code/check_release.py`
compares the tables typed into `paper.tex` with the results and checks that every citation has an entry.

## Reading the result files

- `results/scenarios.csv`: one row per path. Growth rates are percentages over the calendar year named.
  `first_30` is the first date trailing twelve-month growth exceeds 30%. `event` says why a run stopped
  early: `rate` or `stock` is a numerical cutoff, and empty means it reached the horizon.
- `results/annual.csv`: all four stocks and the experience stock for each path. `Y`, `YH`, `YA` and `YR`
  are annualized dollar flows, `K` is H100-equivalents, `F` is H100-equivalents a year, `R` is robots,
  `P` and `GW` are power capacity and demand in GW.
- `results/four_stock_baseline.csv` and `results/one_stock_baseline.csv`: quarterly levels in trillions of
  2026 dollars and trailing twelve-month growth as a fraction. Growth in calendar 2040 is the January 2041
  row: 794.8% in the full model and 966.0% in the formula.

## Reference material

- `reference/source-register.md`: every source, what it supports and where it is used.
- `reference/references.bib`: the same list as BibTeX.
- `reference/epoch-chip-sales-2026-11-22.csv`: the Epoch AI chip-sales snapshot behind the calibration
  checks; `reference/epoch-sales-source.md` gives its licence and provenance.
- `reference/published_summary.csv` and `reference/one_stock_baseline.csv`: results of the first release,
  kept for comparison. Growth there is a fraction, and its `blowup` column is a solver cutoff.

## What is not produced by code

The calibration (Table 5) is taken from the sources in the register. The three numbers of the one formula
(A x1.5 a year, n x1.4, s 7%) were chosen by hand to track the full-model baseline; the package shows how
close they come and does not re-estimate them.
