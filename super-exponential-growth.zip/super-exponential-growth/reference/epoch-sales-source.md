The unmodified file epoch-chip-sales-2026-11-22.csv is from Epoch AI, Data on AI Chip Sales, downloaded on 22 November 2026. Epoch AI licenses these data under CC BY 4.0.

[Dataset and attribution](https://epoch.ai/data/ai-chip-sales) · [CSV](https://epoch.ai/data/ai_chip_sales_timelines_by_chip.csv) · [Methodology](https://epoch.ai/data/ai-chip-sales-documentation/methodology) · [License](https://creativecommons.org/licenses/by/4.0/)

The Q4 2025 price comparison sums estimated chip expenditure across rows reporting positive cost and divides by the estimated H100-equivalents in those same rows. The Siyuan 590 row has zero reported cost and is omitted from both parts of this price calculation. It is retained in the sales totals. This is a chip-only sales-mix estimate.
